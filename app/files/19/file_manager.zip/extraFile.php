<div class='form-group'>
    <label for='exampleInputFile'>File input</label>
    <input type='file' id='exampleInputFile'>
    <p class='help-block'>Example block-level help text here.</p>
</div>
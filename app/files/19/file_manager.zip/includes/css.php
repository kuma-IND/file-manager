<?php
$css_files = ["style"];
getAssetVersion($css_files);
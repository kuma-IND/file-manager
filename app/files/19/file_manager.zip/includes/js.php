<?php

$js_files = ["script"];
getAssetVersion($js_files, "js");
